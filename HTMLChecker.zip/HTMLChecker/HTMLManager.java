import java.util.*;

public class HTMLManager {
  private Queue<HTMLTag> tags;
  
}
